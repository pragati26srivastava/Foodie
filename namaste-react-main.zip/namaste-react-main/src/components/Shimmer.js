const Shimmer = () => {

    return(
        <div className="flex flex-wrap mx-12  shadow-lg justify-evenly">
            <div className = "w-[18vw] h-[42vh]  bg-gray-100 m-4 rounded-lg p-1 " ></div>
            <div className = "w-[18vw] h-[42vh]  bg-gray-100 m-4 rounded-lg p-1 " ></div>
            <div className = "w-[18vw] h-[42vh]  bg-gray-100 m-4 rounded-lg p-1 " ></div>
            <div className = "w-[18vw] h-[42vh]  bg-gray-100 m-4 rounded-lg p-1 " ></div>
            <div className = "w-[18vw] h-[42vh]  bg-gray-100 m-4 rounded-lg p-1 " ></div>
            <div className = "w-[18vw] h-[42vh]  bg-gray-100 m-4 rounded-lg p-1 " ></div>
            <div className = "w-[18vw] h-[42vh]  bg-gray-100 m-4 rounded-lg p-1 " ></div>
            <div className = "w-[18vw] h-[42vh]  bg-gray-100 m-4 rounded-lg p-1 " ></div>
            <div className = "w-[18vw] h-[42vh]  bg-gray-100 m-4 rounded-lg p-1 " ></div>
            <div className = "w-[18vw] h-[42vh]  bg-gray-100 m-4 rounded-lg p-1 " ></div>
            <div className = "w-[18vw] h-[42vh]  bg-gray-100 m-4 rounded-lg p-1 " ></div>
            <div className = "w-[18vw] h-[42vh]  bg-gray-100 m-4 rounded-lg p-1 " ></div>
            <div className = "w-[18vw] h-[42vh]  bg-gray-100 m-4 rounded-lg p-1 " ></div>
            <div className = "w-[18vw] h-[42vh]  bg-gray-100 m-4 rounded-lg p-1 " ></div>
            <div className = "w-[18vw] h-[42vh]  bg-gray-100 m-4 rounded-lg p-1 " ></div>
            <div className = "w-[18vw] h-[42vh]  bg-gray-100 m-4 rounded-lg p-1 " ></div>

        </div>
    )

};

export default Shimmer;