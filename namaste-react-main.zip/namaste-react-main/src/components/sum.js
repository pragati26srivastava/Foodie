export const sum = (a,b) => {
    return a + b;
};

// const sum = (a, b) => {
//     return a + b;
// };

// module.exports = { sum };
